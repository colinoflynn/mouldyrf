*****Process Details*****

-1.6mm FR4 Material
-RoHS Compliant
-Black Soldermask
-Silkscreen top only
-Immersion Gold Plated

*****File Info*********
sma_board.GTO:      Top Silkscreen
sma_board.GTS:      Top Soldermask
sma_board.GTL:      Top Copper Layer
sma_board.GBL:      Bottom Copper Layer
sma_board.GBS:      Bottom Soldermask
sma_board.GTO:      Milling Outline

sma_board.XLN:  NC Drill
